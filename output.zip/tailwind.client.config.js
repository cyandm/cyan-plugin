/** @type {import('tailwindcss').Config} */
module.exports = {
	content: [
		'./templates/client/**/*.php', // فایل‌های تمپلیت
	],
	theme: {
		extend: {},
	},
	plugins: [],
};
