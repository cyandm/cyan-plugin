/** @type {import('tailwindcss').Config} */
module.exports = {
	content: [
		'./templates/admin/**/*.php', // فایل‌های تمپلیت
	],
	theme: {
		extend: {},
	},
	plugins: [],
};
