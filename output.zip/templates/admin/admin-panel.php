<div class="wrap">
	<h1>
		تنظیمات پلاگین سایان
	</h1>
</div>